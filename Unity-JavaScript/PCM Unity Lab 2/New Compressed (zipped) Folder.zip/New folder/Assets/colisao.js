#pragma strict


function OnCollisionEnter(objbateu: Collision)
{
	if (objbateu.gameObject.name=="BarraDir")
	{
		bola_x = bola_x * -1;
	}
	
	if (objbateu.gameObject.name=="BarraEsc")
	{
		bola_x = bola_x * -1;
	}
	
	if (objbateu.gameObject.name=="BarraTopo")
	{
		bola_y = bola_y * -1;
	}
}