#pragma strict

static var bola_x: float = 1;
static var bola_y: float = 1;
var vidas: int =3;
var pontos: int =0;                                                   

function Start () {

}

function Update () {

	if (transform.position.y<-5)
	{
		vidas=vidas-1;
		if(vidas<0)
		{
			Application.LoadLevel("MainMenu");
			Invoke("MainMenu",2);
		}
		
		transform.position.x=0;
		transform.position.y=-7;
	}
	
	var x=Time.deltaTime*bola_x;
	var y=Time.deltaTime*bola_y;
	
	transform.Translate(y,x,0);
}