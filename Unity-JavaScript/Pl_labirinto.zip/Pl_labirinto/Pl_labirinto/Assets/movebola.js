#pragma strict

function Start () {

}

var velo=5.0;

function Update () {

var x=Input.GetAxis("Horizontal")*Time.deltaTime*velo;
var z=Input.GetAxis("Vertical")*Time.deltaTime*velo;

transform.Translate(z, 0, x);
}